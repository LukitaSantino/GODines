import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32
import numpy as np


class SignalGenerator(Node):
    def __init__(self):
        super().__init__('signal_generator')
        
        # Publishers
        self.signal_publisher = self.create_publisher(Float32, '/signal', 10)
        self.time_publisher = self.create_publisher(Float32, '/time', 10)
        
        # Timer - 10 Hz = 0.1 seconds
        self.timer = self.create_timer(0.1, self.timer_callback)
        
        # Initialize time
        self.start_time = self.get_clock().now()
        
        self.get_logger().info('Signal Generator Node has been started')
    
    def timer_callback(self):
        # Calculate elapsed time
        current_time = self.get_clock().now()
        elapsed_time = (current_time - self.start_time).nanoseconds / 1e9
        
        # Generate sine wave: y(t) = sin(t)
        signal_value = np.sin(elapsed_time)
        
        # Create messages
        signal_msg = Float32()
        signal_msg.data = float(signal_value)
        
        time_msg = Float32()
        time_msg.data = float(elapsed_time)
        
        # Publish messages
        self.signal_publisher.publish(signal_msg)
        self.time_publisher.publish(time_msg)
        
        # Log to terminal
        self.get_logger().info(f'Time: {elapsed_time:.2f}s, Signal: {signal_value:.4f}')


def main(args=None):
    rclpy.init(args=args)
    node = SignalGenerator()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()