import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32
import numpy as np


class ProcessNode(Node):
    def __init__(self):
        super().__init__('process')
        
        # Subscribers
        self.signal_subscription = self.create_subscription(
            Float32,
            '/signal',
            self.signal_callback,
            10)
        
        self.time_subscription = self.create_subscription(
            Float32,
            '/time',
            self.time_callback,
            10)
        
        # Publisher
        self.proc_signal_publisher = self.create_publisher(Float32, '/proc_signal', 10)
        
        # Timer - 10 Hz
        self.timer = self.create_timer(0.1, self.timer_callback)
        
        # Variables to store received data
        self.current_signal = 0.0
        self.current_time = 0.0
        
        # Phase shift parameter (in radians)
        self.phase_shift = np.pi / 4  # 45 degrees - PUEDES CAMBIAR ESTE VALOR
        
        self.get_logger().info('Process Node has been started')
        self.get_logger().info(f'Phase shift: {self.phase_shift:.4f} rad ({np.degrees(self.phase_shift):.2f}°)')
    
    def signal_callback(self, msg):
        self.current_signal = msg.data
    
    def time_callback(self, msg):
        self.current_time = msg.data
    
    def timer_callback(self):
        # Process the signal:
        # 1. Add phase shift: sin(t + φ)
        # 2. Add offset to make positive: sin(t + φ) + 1
        # 3. Reduce amplitude by half: [sin(t + φ) + 1] / 2
        
        signal_with_phase = np.sin(self.current_time + self.phase_shift)
        offset_signal = signal_with_phase + 1.0
        processed_signal = offset_signal / 2.0
        
        # Create and publish message
        proc_msg = Float32()
        proc_msg.data = float(processed_signal)
        self.proc_signal_publisher.publish(proc_msg)
        
        # Log to terminal
        self.get_logger().info(
            f'Time: {self.current_time:.2f}s, '
            f'Input: {self.current_signal:.4f}, '
            f'Processed: {processed_signal:.4f}'
        )


def main(args=None):
    rclpy.init(args=args)
    node = ProcessNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()