from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import ExecuteProcess


def generate_launch_description():
    return LaunchDescription([
        # Signal Generator Node
        Node(
            package='signal_processing',
            executable='signal_generator',
            name='signal_generator',
            output='screen',
            prefix='gnome-terminal --'
        ),
        
        # Process Node
        Node(
            package='signal_processing',
            executable='process',
            name='process',
            output='screen',
            prefix='gnome-terminal --'
        ),
        
        # rqt_plot
        ExecuteProcess(
            cmd=['ros2', 'run', 'rqt_plot', 'rqt_plot', 
                 '/signal/data', '/proc_signal/data'],
            output='screen'
        ),
    ])
