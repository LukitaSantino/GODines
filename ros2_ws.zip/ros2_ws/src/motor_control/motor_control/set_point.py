# Imports
import rclpy
from rclpy.node import Node
import numpy as np
from std_msgs.msg import Float32
from rcl_interfaces.msg import SetParametersResult


# Class Definition
class SetPointPublisher(Node):
    def __init__(self):
        super().__init__('set_point_node')

        # ── Parameters ──────────────────────────────────────────────────────
        self.declare_parameter('amplitude', 2.0)
        self.declare_parameter('omega', 1.0)
        # Signal type: 'sine' | 'square' | 'step'
        self.declare_parameter('signal_type', 'sine')

        self.amplitude   = self.get_parameter('amplitude').value
        self.omega       = self.get_parameter('omega').value
        self.signal_type = self.get_parameter('signal_type').value

        self.add_on_set_parameters_callback(self.parameters_callback)

        # ── Publisher ────────────────────────────────────────────────────────
        self.signal_publisher = self.create_publisher(Float32, 'set_point', 10)
        self.signal_msg = Float32()
        self.start_time = self.get_clock().now()

        timer_period = 0.1  # seconds
        self.timer = self.create_timer(timer_period, self.timer_cb)

        self.get_logger().info('SetPoint Node Started 🚀')

    # ── Timer Callback ───────────────────────────────────────────────────────
    def timer_cb(self):
        elapsed = (self.get_clock().now() - self.start_time).nanoseconds / 1e9

        if self.signal_type == 'sine':
            value = self.amplitude * np.sin(self.omega * elapsed)
        elif self.signal_type == 'square':
            value = self.amplitude * float(np.sign(np.sin(self.omega * elapsed)))
        else:  # 'step'
            value = self.amplitude

        self.signal_msg.data = float(value)
        self.signal_publisher.publish(self.signal_msg)

    # ── Parameter Callback ───────────────────────────────────────────────────
    def parameters_callback(self, params):
        valid_types = ('sine', 'square', 'step')
        for param in params:
            if param.name == 'amplitude':
                self.amplitude = param.value
                self.get_logger().info(f'amplitude updated to {self.amplitude}')
            elif param.name == 'omega':
                self.omega = param.value
                self.get_logger().info(f'omega updated to {self.omega}')
            elif param.name == 'signal_type':
                if param.value not in valid_types:
                    self.get_logger().warn(
                        f"Invalid signal_type '{param.value}'. Choose: {valid_types}"
                    )
                    return SetParametersResult(
                        successful=False,
                        reason=f"signal_type must be one of {valid_types}"
                    )
                self.signal_type = param.value
                self.get_logger().info(f'signal_type updated to {self.signal_type}')
        return SetParametersResult(successful=True)


# Main
def main(args=None):
    rclpy.init(args=args)
    node = SetPointPublisher()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.try_shutdown()


if __name__ == '__main__':
    main()