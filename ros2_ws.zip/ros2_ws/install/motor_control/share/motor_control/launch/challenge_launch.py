"""
challenge_launch.py
-------------------
Lanza 3 grupos de control de motor con namespaces:
  - group1, group2, group3
Cada grupo tiene: motor_sys, sp_gen, ctrl
"""

from launch import LaunchDescription
from launch_ros.actions import Node, PushRosNamespace
from launch.actions import GroupAction


def generate_launch_description():

    params = [{
        'sample_time':        0.01,
        'sys_gain_K':         2.16,
        'sys_tau_T':          0.05,
        'initial_conditions': 0.0,
    }]

    ctrl_params = [{
        'sample_time': 0.01,
        'Kp':          1.5,
        'Ki':          1.0,
        'Kd':          0.0,
    }]

    def make_group(ns):
        return GroupAction(actions=[
            PushRosNamespace(ns),
            Node(name='motor_sys', package='motor_control', executable='dc_motor',
                 emulate_tty=True, output='screen', parameters=params),
            Node(name='sp_gen', package='motor_control', executable='set_point',
                 emulate_tty=True, output='screen'),
            Node(name='ctrl', package='motor_control', executable='controller',
                 emulate_tty=True, output='screen', parameters=ctrl_params),
        ])

    return LaunchDescription([
        make_group('group1'),
        make_group('group2'),
        make_group('group3'),
    ])